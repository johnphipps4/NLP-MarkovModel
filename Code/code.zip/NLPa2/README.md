## NLPa2
## Team Members: Benjamin Steeper (bd238); John Trujillo (jpt86); Elaine Hwang (yh467)

#Installation
sklearn: pip install sklearn

#To run the file
python3 proj2.py
